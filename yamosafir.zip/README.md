# يا مسافر

تطبيق أندرويد يعرض صفحة index.html داخل نافذة WebView.
للبناء: ارفع محتويات المجلد إلى مستودع GitHub، ثم من تبويب Actions حمّل ملف yamosafir-apk.
